# ReUseLoop backend setup

This backend uses Supabase Auth, PostgreSQL, Row Level Security (RLS), and Supabase Storage.

## 1. Create the database
1. Create a project at https://supabase.com.
2. Open **SQL Editor** -> **New query**.
3. Open `supabase/schema.sql`, copy all its contents, paste into SQL Editor, and click **Run**.
4. The script creates profiles, listings, favorites, requests, reports, circular history, security policies, and a public `listing-images` storage bucket.

## 2. Configure the frontend
1. In Supabase, open **Project Settings** -> **API** (or **API Keys**).
2. Copy the Project URL and the publishable/anon key.
3. Copy `.env.example` to `.env` in the frontend project root.
4. Replace the two placeholder values. Never put a `service_role` or secret key in browser code.
5. Install dependency: `npm install @supabase/supabase-js`.
6. Use `src/lib/supabase.js` as the shared client.

## 3. Upload these files to GitHub
Upload the `supabase` folder, `src/lib/supabase.js`, `src/services` folder, `.env.example`, and `BACKEND_SETUP.md`.
Do NOT upload your real `.env` file or any secret keys.

## 4. Important notes
- The SQL file sets up database tables and basic RLS access rules. It does not automatically connect the existing UI; import the service functions from your React/Vite components.
- Set the first admin role manually in Supabase SQL Editor after creating your account:
  `update public.profiles set role = 'admin' where email = 'YOUR_EMAIL';`
  Replace with your own registered email. Do not expose admin privileges in client-side code.
- Email confirmation may need to be enabled/disabled in Supabase Authentication settings depending on your testing needs.
- Test with two separate student accounts before presenting the project.
