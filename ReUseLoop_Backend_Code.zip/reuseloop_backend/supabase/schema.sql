-- ReUseLoop database schema for Supabase (PostgreSQL)
-- Run this entire file in Supabase Dashboard -> SQL Editor -> New query.
create extension if not exists pgcrypto;

do $$ begin
  create type public.user_role as enum ('student', 'admin');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.listing_type as enum ('sell', 'rent', 'donate', 'swap');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.listing_status as enum ('active', 'reserved', 'completed', 'removed');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.request_status as enum ('pending', 'accepted', 'rejected', 'cancelled', 'completed');
exception when duplicate_object then null; end $$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  email text,
  college_name text not null default '',
  department text default '',
  course_year text default '',
  phone text,
  avatar_url text,
  role public.user_role not null default 'student',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 3 and 120),
  description text not null default '',
  category text not null,
  listing_type public.listing_type not null,
  price numeric(10,2) not null default 0 check (price >= 0),
  condition text not null default 'good',
  image_urls text[] not null default '{}',
  college_name text not null,
  location text default '',
  status public.listing_status not null default 'active',
  views integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.favorites (
  user_id uuid not null references public.profiles(id) on delete cascade,
  listing_id uuid not null references public.listings(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, listing_id)
);

create table if not exists public.requests (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.listings(id) on delete cascade,
  requester_id uuid not null references public.profiles(id) on delete cascade,
  owner_id uuid not null references public.profiles(id) on delete cascade,
  message text default '',
  status public.request_status not null default 'pending',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint different_request_parties check (requester_id <> owner_id)
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  listing_id uuid references public.listings(id) on delete set null,
  reported_user_id uuid references public.profiles(id) on delete set null,
  reason text not null,
  details text default '',
  status text not null default 'open' check (status in ('open','reviewing','resolved','dismissed')),
  created_at timestamptz not null default now()
);

create table if not exists public.circular_history (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid references public.listings(id) on delete set null,
  giver_id uuid references public.profiles(id) on delete set null,
  receiver_id uuid references public.profiles(id) on delete set null,
  action text not null check (action in ('sold','rented','donated','swapped')),
  estimated_money_saved numeric(10,2) not null default 0 check (estimated_money_saved >= 0),
  created_at timestamptz not null default now()
);

create index if not exists listings_owner_idx on public.listings(owner_id);
create index if not exists listings_status_created_idx on public.listings(status, created_at desc);
create index if not exists listings_category_idx on public.listings(category);
create index if not exists requests_owner_idx on public.requests(owner_id, status);
create index if not exists requests_requester_idx on public.requests(requester_id, status);
create index if not exists reports_status_idx on public.reports(status);

-- Create a profile automatically whenever a user signs up through Supabase Auth.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, full_name, email, college_name)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    new.email,
    coalesce(new.raw_user_meta_data ->> 'college_name', '')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Keep updated_at current on edited rows.
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists profiles_set_updated_at on public.profiles;
create trigger profiles_set_updated_at before update on public.profiles
for each row execute procedure public.set_updated_at();

drop trigger if exists listings_set_updated_at on public.listings;
create trigger listings_set_updated_at before update on public.listings
for each row execute procedure public.set_updated_at();

drop trigger if exists requests_set_updated_at on public.requests;
create trigger requests_set_updated_at before update on public.requests
for each row execute procedure public.set_updated_at();

-- Row Level Security
alter table public.profiles enable row level security;
alter table public.listings enable row level security;
alter table public.favorites enable row level security;
alter table public.requests enable row level security;
alter table public.reports enable row level security;
alter table public.circular_history enable row level security;

-- Profiles: signed-in users can view profiles; each user edits only their own profile.
drop policy if exists "Profiles visible to authenticated users" on public.profiles;
create policy "Profiles visible to authenticated users" on public.profiles
for select to authenticated using (true);
drop policy if exists "Users insert own profile" on public.profiles;
create policy "Users insert own profile" on public.profiles
for insert to authenticated with check (auth.uid() = id);
drop policy if exists "Users update own profile" on public.profiles;
create policy "Users update own profile" on public.profiles
for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

-- Listings: public catalogue is readable; only owner can create/edit/delete.
drop policy if exists "Anyone can view active listings" on public.listings;
create policy "Anyone can view active listings" on public.listings
for select using (status = 'active' or auth.uid() = owner_id);
drop policy if exists "Users create own listings" on public.listings;
create policy "Users create own listings" on public.listings
for insert to authenticated with check (auth.uid() = owner_id);
drop policy if exists "Owners update own listings" on public.listings;
create policy "Owners update own listings" on public.listings
for update to authenticated using (auth.uid() = owner_id) with check (auth.uid() = owner_id);
drop policy if exists "Owners delete own listings" on public.listings;
create policy "Owners delete own listings" on public.listings
for delete to authenticated using (auth.uid() = owner_id);

-- Favorites: user controls only their own favorites.
drop policy if exists "Users view own favorites" on public.favorites;
create policy "Users view own favorites" on public.favorites
for select to authenticated using (auth.uid() = user_id);
drop policy if exists "Users add own favorites" on public.favorites;
create policy "Users add own favorites" on public.favorites
for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Users remove own favorites" on public.favorites;
create policy "Users remove own favorites" on public.favorites
for delete to authenticated using (auth.uid() = user_id);

-- Requests: requester and listing owner can see; requester creates; owner or requester can update.
drop policy if exists "Parties view requests" on public.requests;
create policy "Parties view requests" on public.requests
for select to authenticated using (auth.uid() = requester_id or auth.uid() = owner_id);
drop policy if exists "Requester creates request" on public.requests;
create policy "Requester creates request" on public.requests
for insert to authenticated with check (
  auth.uid() = requester_id
  and exists (select 1 from public.listings l where l.id = listing_id and l.owner_id = owner_id)
);
drop policy if exists "Parties update requests" on public.requests;
create policy "Parties update requests" on public.requests
for update to authenticated using (auth.uid() = requester_id or auth.uid() = owner_id)
with check (auth.uid() = requester_id or auth.uid() = owner_id);

-- Reports: users can create and see their own reports; admin moderation is performed via trusted admin tooling.
drop policy if exists "Users create reports" on public.reports;
create policy "Users create reports" on public.reports
for insert to authenticated with check (auth.uid() = reporter_id);
drop policy if exists "Users view own reports" on public.reports;
create policy "Users view own reports" on public.reports
for select to authenticated using (auth.uid() = reporter_id);

-- Circular history: signed-in users can view history; rows are inserted by participants.
drop policy if exists "Authenticated view circular history" on public.circular_history;
create policy "Authenticated view circular history" on public.circular_history
for select to authenticated using (true);
drop policy if exists "Participants add circular history" on public.circular_history;
create policy "Participants add circular history" on public.circular_history
for insert to authenticated with check (auth.uid() = giver_id or auth.uid() = receiver_id);

-- Storage bucket for listing photos. Create bucket if it does not exist.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('listing-images', 'listing-images', true, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

drop policy if exists "Public can view listing images" on storage.objects;
create policy "Public can view listing images" on storage.objects
for select using (bucket_id = 'listing-images');

drop policy if exists "Signed-in users upload listing images" on storage.objects;
create policy "Signed-in users upload listing images" on storage.objects
for insert to authenticated with check (
  bucket_id = 'listing-images' and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists "Users update own listing images" on storage.objects;
create policy "Users update own listing images" on storage.objects
for update to authenticated using (
  bucket_id = 'listing-images' and (storage.foldername(name))[1] = auth.uid()::text
) with check (
  bucket_id = 'listing-images' and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists "Users delete own listing images" on storage.objects;
create policy "Users delete own listing images" on storage.objects
for delete to authenticated using (
  bucket_id = 'listing-images' and (storage.foldername(name))[1] = auth.uid()::text
);
