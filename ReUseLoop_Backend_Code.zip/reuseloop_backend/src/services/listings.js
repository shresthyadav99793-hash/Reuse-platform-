import { supabase } from '../lib/supabase';

export async function getListings({ search = '', category = '', type = '' } = {}) {
  let query = supabase.from('listings').select('*, profiles:owner_id(full_name,college_name)')
    .eq('status', 'active').order('created_at', { ascending: false });
  if (category) query = query.eq('category', category);
  if (type) query = query.eq('listing_type', type);
  if (search) query = query.or(`title.ilike.%${search}%,description.ilike.%${search}%`);
  const { data, error } = await query;
  if (error) throw error;
  return data;
}

export async function createListing(listing, imageFiles = []) {
  const { data: authData, error: authError } = await supabase.auth.getUser();
  if (authError) throw authError;
  const user = authData.user;
  if (!user) throw new Error('Please sign in before creating a listing.');

  const imageUrls = [];
  for (const file of imageFiles) {
    const safeName = `${crypto.randomUUID()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, '_')}`;
    const path = `${user.id}/${safeName}`;
    const { error: uploadError } = await supabase.storage.from('listing-images').upload(path, file, { upsert: false });
    if (uploadError) throw uploadError;
    const { data: urlData } = supabase.storage.from('listing-images').getPublicUrl(path);
    imageUrls.push(urlData.publicUrl);
  }

  const { data, error } = await supabase.from('listings').insert({
    ...listing,
    owner_id: user.id,
    image_urls: imageUrls
  }).select().single();
  if (error) throw error;
  return data;
}

export async function updateListing(id, updates) {
  const { data, error } = await supabase.from('listings').update(updates).eq('id', id).select().single();
  if (error) throw error;
  return data;
}

export async function deleteListing(id) {
  const { error } = await supabase.from('listings').delete().eq('id', id);
  if (error) throw error;
}

export async function getMyListings() {
  const { data: userData, error: userError } = await supabase.auth.getUser();
  if (userError) throw userError;
  if (!userData.user) return [];
  const { data, error } = await supabase.from('listings').select('*')
    .eq('owner_id', userData.user.id).order('created_at', { ascending: false });
  if (error) throw error;
  return data;
}
