import { supabase } from '../lib/supabase';

export async function addFavorite(listingId) {
  const { data: { user }, error: userError } = await supabase.auth.getUser();
  if (userError) throw userError;
  if (!user) throw new Error('Please sign in first.');
  const { error } = await supabase.from('favorites').insert({ user_id: user.id, listing_id: listingId });
  if (error) throw error;
}

export async function removeFavorite(listingId) {
  const { data: { user }, error: userError } = await supabase.auth.getUser();
  if (userError) throw userError;
  if (!user) throw new Error('Please sign in first.');
  const { error } = await supabase.from('favorites').delete()
    .eq('user_id', user.id).eq('listing_id', listingId);
  if (error) throw error;
}

export async function createRequest({ listingId, ownerId, message = '' }) {
  const { data: { user }, error: userError } = await supabase.auth.getUser();
  if (userError) throw userError;
  if (!user) throw new Error('Please sign in first.');
  const { data, error } = await supabase.from('requests').insert({
    listing_id: listingId, requester_id: user.id, owner_id: ownerId, message
  }).select().single();
  if (error) throw error;
  return data;
}

export async function updateRequestStatus(requestId, status) {
  const { data, error } = await supabase.from('requests').update({ status })
    .eq('id', requestId).select().single();
  if (error) throw error;
  return data;
}

export async function reportListing({ listingId, reportedUserId, reason, details = '' }) {
  const { data: { user }, error: userError } = await supabase.auth.getUser();
  if (userError) throw userError;
  if (!user) throw new Error('Please sign in first.');
  const { data, error } = await supabase.from('reports').insert({
    reporter_id: user.id, listing_id: listingId, reported_user_id: reportedUserId, reason, details
  }).select().single();
  if (error) throw error;
  return data;
}

export async function updateMyProfile(updates) {
  const { data: { user }, error: userError } = await supabase.auth.getUser();
  if (userError) throw userError;
  if (!user) throw new Error('Please sign in first.');
  const { data, error } = await supabase.from('profiles').update(updates)
    .eq('id', user.id).select().single();
  if (error) throw error;
  return data;
}
